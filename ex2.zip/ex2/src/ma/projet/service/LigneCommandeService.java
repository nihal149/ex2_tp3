package ma.projet.service;

import ma.projet.dao.IDao;
import ma.projet.classes.LigneCommandeProduit;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

public class LigneCommandeService implements IDao<LigneCommandeProduit> {

    @Override
    public boolean create(LigneCommandeProduit lc) {
        Session session = null;
        Transaction tx = null;
        boolean etat = false;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(lc);
            tx.commit();
            etat = true;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
        } finally {
            if (session != null) session.close();
        }
        return etat;
    }

    @Override
    public LigneCommandeProduit getById(int id) {
        Session session = null;
        LigneCommandeProduit ligneCommande = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            ligneCommande = (LigneCommandeProduit) session.get(LigneCommandeProduit.class, id);
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }
        return ligneCommande;
    }

    @Override
    public List<LigneCommandeProduit> getAll() {
        Session session = null;
        List<LigneCommandeProduit> lignesCommandes = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            lignesCommandes = session.createQuery("from LigneCommandeProduit").list();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }
        return lignesCommandes;
    }
}
