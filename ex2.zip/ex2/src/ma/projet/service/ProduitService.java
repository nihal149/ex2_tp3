package ma.projet.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import ma.projet.dao.IDao;
import ma.projet.classes.Produit;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import ma.projet.classes.Commande;
import ma.projet.classes.LigneCommandeProduit;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

public class ProduitService implements IDao<Produit> {

    @Override
    public boolean create(Produit p) {
        Session session = null;
        Transaction tx = null;
        boolean etat = false;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(p);
            tx.commit();
            etat = true;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
        } finally {
            if (session != null) session.close();
        }
        return etat;
    }

    @Override
    public Produit getById(int id) {
        Session session = null;
        Produit produit = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            produit = (Produit) session.get(Produit.class, id);
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }
        return produit;
    }

    @Override
    public List<Produit> getAll() {
        Session session = null;
        List<Produit> produits = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            produits = session.createQuery("from Produit").list();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }
        return produits;
    }
    
    public List<Produit> getProduitsByCategorie(int categorieId) {
    List<Produit> produits = getAll();
    List<Produit> produitsFiltrés = new ArrayList<>(); 
   
    for (Produit produit : produits) {
        if (produit.getCategorie() != null && produit.getCategorie().getId() == categorieId) {
            produitsFiltrés.add(produit);
        }
    }

    return produitsFiltrés; 
}
    
        // Méthode pour afficher les produits entre deux dates
    public static void afficherProduitsCommandesEntreDeuxDates(List<Commande> commandes) {
    Scanner scanner = new Scanner(System.in);
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    try {
        System.out.print("\nEntrez la première date (dd/MM/yyyy) : ");
        Date date1 = sdf.parse(scanner.nextLine());

        System.out.print("Entrez la deuxième date (dd/MM/yyyy) : ");
        Date date2 = sdf.parse(scanner.nextLine());

        System.out.println("\nProduits commandés entre " + sdf.format(date1) + " et " + sdf.format(date2) + " :");

        
        List<Produit> produitsTrouves = new ArrayList<>();

      
        for (Commande commande : commandes) {
            Date dateCommande = commande.getDate();
            
            if (dateCommande != null && !dateCommande.before(date1) && !dateCommande.after(date2)) {
               
                for (LigneCommandeProduit ligne : commande.getLignesCommande()) {
                    produitsTrouves.add(ligne.getProduit()); 
                }
            }
        }

     
        if (produitsTrouves.isEmpty()) {
            System.out.println("Aucun produit trouvé entre ces dates.");
        } else {
            produitsTrouves.forEach(produit -> 
                System.out.println("Produit{id=" + produit.getId() + 
                                   ", reference='" + produit.getReference() + 
                                   "', prix=" + produit.getPrix() + 
                                   ", categorie='" + (produit.getCategorie() != null ? produit.getCategorie().getLibelle() : "N/A") + "'}"));
        }
    } catch (ParseException e) {
        System.out.println("Erreur de format de date.");
    } finally {
        scanner.close(); 
    }
}
    
    private static void afficherProduitsDeLaCommande(Commande commande) {
    if (commande == null) {
        System.out.println("Commande introuvable.");
        return;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
    
    
    System.out.println("Commande : " + commande.getId() + " Date : " + sdf.format(commande.getDate()));
    System.out.println("Liste des produits :");
    System.out.println("Référence\tPrix\tQuantité");
  
    for (LigneCommandeProduit ligne : commande.getLignesCommande()) {
        Produit produit = ligne.getProduit();
        int quantite = ligne.getQuantite();

       
        System.out.println(produit.getReference() + "\t" + produit.getPrix() + " DH\t" + quantite);
    }
}
    
      
   
  

private static void afficherProduitsSupérieursA(List<Produit> produits) {
    double prixMin = 100; // Montant fixe
    System.out.println("\nProduits avec prix supérieur à " + prixMin + " DH :");
    produits.stream()
            .filter(produit -> produit.getPrix() > prixMin)
            .forEach(produit -> System.out.println("Produit{id=" + produit.getId() + 
                                                   ", reference='" + produit.getReference() + 
                                                   "', prix=" + produit.getPrix() + 
                                                   ", categorie='" + 
                                                   (produit.getCategorie() != null ? produit.getCategorie().getLibelle() : "N/A") + "'}"));
}







    
}