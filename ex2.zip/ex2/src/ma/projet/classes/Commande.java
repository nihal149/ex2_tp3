package ma.projet.classes;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "commandes") // Nom de la table
public class Commande {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "date")
    private Date date;

    @OneToMany(mappedBy = "commande", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LigneCommandeProduit> lignesCommande = new ArrayList<>();

    public Commande() {}

    public Commande(Date date) {
        this.date = date;
    }

    // Getters et Setters

    public int getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public List<LigneCommandeProduit> getLignesCommande() {
        return lignesCommande;
    }

    public void ajouterLigneCommande(LigneCommandeProduit ligne) {
        lignesCommande.add(ligne);
        ligne.setCommande(this); // Établir la relation inverse
    }

     public void addLigneCommande(LigneCommandeProduit ligneCommande) {
        lignesCommande.add(ligneCommande); // Ajouter la ligne de commande à la liste
    }
}
