package ma.projet.classes;

import javax.persistence.*;

@Entity
@Table(name = "produits") // Nom de la table
@NamedQueries({
    @NamedQuery(name = "Produit.findByPriceGreaterThan", query = "SELECT p FROM Produit p WHERE p.prix > 100")
})
public class Produit {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "reference")
    private String reference;

    @Column(name = "prix")
    private double prix;

    @ManyToOne // Relation many-to-one
    @JoinColumn(name = "categorie_id") // Nom de la colonne étrangère
    private Categorie categorie;

    public Produit() {}

    public Produit(String reference, double prix) {
        this.reference = reference;
        this.prix = prix;
    }

    // Getters et Setters

    public int getId() {
        return id;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }
}
