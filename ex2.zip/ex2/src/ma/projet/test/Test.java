package ma.projet.test;

import ma.projet.classes.Categorie;
import ma.projet.classes.Produit;
import ma.projet.service.ProduitService;
import ma.projet.classes.Commande;
import ma.projet.classes.LigneCommandeProduit;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        ProduitService produitService = new ProduitService();

      
        Categorie categorieElectronique = new Categorie("C001", "Électronique");
        Categorie categorieMaison = new Categorie("C002", "Maison");

        // 2. Créer des produits
        Produit smartphone = new Produit("P001", 1500.0); // Smartphone
        Produit ordinateurPortable = new Produit("P002", 2000.0); // Ordinateur portable
        Produit aspirateur = new Produit("P003", 300.0); // Aspirateur
        Produit grillePain = new Produit("P004", 800.0); // Grille-pain

        // Associer les catégories aux produits
        smartphone.setCategorie(categorieElectronique);
        ordinateurPortable.setCategorie(categorieElectronique);
        aspirateur.setCategorie(categorieMaison);
        grillePain.setCategorie(categorieMaison);

        // 3. Tester la méthode create
        System.out.println("Test de la création de produits :");
        System.out.println("Produit créé : " + produitService.create(smartphone));
        System.out.println("Produit créé : " + produitService.create(ordinateurPortable));
        System.out.println("Produit créé : " + produitService.create(aspirateur));
        System.out.println("Produit créé : " + produitService.create(grillePain));

        // 4. Tester la méthode getById
        System.out.println("\nTest de la récupération d'un produit par ID :");
        Produit retrievedProduit = produitService.getById(1);
        System.out.println("Produit récupéré : " + retrievedProduit.getReference() + ", " + retrievedProduit.getPrix() + " DH");

        // 5. Tester la méthode getAll
        System.out.println("\nTest de la récupération de tous les produits :");
        List<Produit> allProduits = produitService.getAll();
        allProduits.forEach(produit -> 
            System.out.println("Produit{id=" + produit.getId() + 
                               ", reference='" + produit.getReference() + 
                               "', prix=" + produit.getPrix() + 
                               ", categorie='" + (produit.getCategorie() != null ? produit.getCategorie().getLibelle() : "N/A") + "'}"));

        // 6. Tester la méthode getProduitsByCategorie
        System.out.println("\nTest de la récupération des produits par catégorie (Électronique) :");
        List<Produit> produitsElectro = produitService.getProduitsByCategorie(categorieElectronique.getId());
        produitsElectro.forEach(produit -> 
            System.out.println("Produit{id=" + produit.getId() + 
                               ", reference='" + produit.getReference() + 
                               "', prix=" + produit.getPrix() + 
                               ", categorie='" + (produit.getCategorie() != null ? produit.getCategorie().getLibelle() : "N/A") + "'}"));

        // 7. Tester la méthode afficherProduitsSupérieursA
        System.out.println("\nTest de l'affichage des produits avec un prix supérieur à 100 DH :");
        afficherProduitsSupérieursA(allProduits); // Appel à la méthode modifiée

        // 8. Préparer quelques commandes pour tester l'affichage des produits entre deux dates
        List<Commande> commandes = new ArrayList<>();
        Commande commande1 = new Commande(parseDate("01/10/2024"));
        commande1.addLigneCommande(new LigneCommandeProduit(1, smartphone));
        commande1.addLigneCommande(new LigneCommandeProduit(1, ordinateurPortable));
        
        Commande commande2 = new Commande(parseDate("15/10/2024"));
        commande2.addLigneCommande(new LigneCommandeProduit(2, aspirateur));
        
        Commande commande3 = new Commande(parseDate("20/10/2024"));
        commande3.addLigneCommande(new LigneCommandeProduit(1, grillePain));

        // Ajout des commandes à la liste
        commandes.add(commande1);
        commandes.add(commande2);
        commandes.add(commande3);

        // 9. Tester l'affichage des produits entre deux dates
        System.out.println("\nTest de l'affichage des produits commandés entre le 01/10/2024 et le 20/10/2024 :");
        produitService.afficherProduitsCommandesEntreDeuxDates(commandes);
    }

    private static void afficherProduitsSupérieursA(List<Produit> produits) {
        double prixMin = 100; // Montant fixe
        System.out.println("\nProduits avec prix supérieur à " + prixMin + " DH :");
        produits.stream()
                .filter(produit -> produit.getPrix() > prixMin)
                .forEach(produit -> System.out.println("Produit{id=" + produit.getId() + 
                                                       ", reference='" + produit.getReference() + 
                                                       "', prix=" + produit.getPrix() + 
                                                       ", categorie='" + 
                                                       (produit.getCategorie() != null ? produit.getCategorie().getLibelle() : "N/A") + "'}"));
    }

    private static Date parseDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            return sdf.parse(dateStr);
        } catch (Exception e) {
            return null;
        }
    }
}
